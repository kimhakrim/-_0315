package member;

public class ZipcodeBean {

}
