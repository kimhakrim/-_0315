package service;

public class ReplyVo {

	private int cridx;
	private String crcontent;
	private String crwriter;
	private String crwriteday;
	private String origincridx;
	private String crlevel;
	private String crdepth;
	private int crcommend;
	private int crdecommend;
	private String crdelyn;
	
	public int getCridx() {
		return cridx;
	}
	public void setCridx(int cridx) {
		this.cridx = cridx;
	}
	public String getCrcontent() {
		return crcontent;
	}
	public void setCrcontent(String crcontent) {
		this.crcontent = crcontent;
	}
	public String getCrwriter() {
		return crwriter;
	}
	public void setCrwriter(String crwriter) {
		this.crwriter = crwriter;
	}
	public String getCrwriteday() {
		return crwriteday;
	}
	public void setCrwriteday(String crwriteday) {
		this.crwriteday = crwriteday;
	}
	public String getOrigincridx() {
		return origincridx;
	}
	public void setOrigincridx(String origincridx) {
		this.origincridx = origincridx;
	}
	public String getCrlevel() {
		return crlevel;
	}
	public void setCrlevel(String crlevel) {
		this.crlevel = crlevel;
	}
	public String getCrdepth() {
		return crdepth;
	}
	public void setCrdepth(String crdepth) {
		this.crdepth = crdepth;
	}
	public int getCrcommend() {
		return crcommend;
	}
	public void setCrcommend(int crcommend) {
		this.crcommend = crcommend;
	}
	public int getCrdecommend() {
		return crdecommend;
	}
	public void setCrdecommend(int crdecommend) {
		this.crdecommend = crdecommend;
	}
	public String getCrdelyn() {
		return crdelyn;
	}
	public void setCrdelyn(String crdelyn) {
		this.crdelyn = crdelyn;
	}
	
		
}
