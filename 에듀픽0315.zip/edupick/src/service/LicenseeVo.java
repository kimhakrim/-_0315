package service;

public class LicenseeVo {

	private int lidx;
	private String lid;
	private String lname;
	private String lpwd;
	private String ljumin;
	private String lpostcode;
	private String lroadaddr;
	private String ljibunaddr;
	private String ldetailaddr;
	private String lextraaddr;
	private String lemail;
	private String ltel;
	private String lcomname;
	private String lnumber;
	private String ljoindate;
	private String loutdate;
	private String loutyn;
	private String ldelyn;
	
	public String getLpostcode() {
		return lpostcode;
	}
	public void setLpostcode(String lpostcode) {
		this.lpostcode = lpostcode;
	}
	public String getLroadaddr() {
		return lroadaddr;
	}
	public void setLroadaddr(String lroadaddr) {
		this.lroadaddr = lroadaddr;
	}
	public String getLjibunaddr() {
		return ljibunaddr;
	}
	public void setLjibunaddr(String ljibunaddr) {
		this.ljibunaddr = ljibunaddr;
	}
	public String getLdetailaddr() {
		return ldetailaddr;
	}
	public void setLdetailaddr(String ldetailaddr) {
		this.ldetailaddr = ldetailaddr;
	}
	public String getLextraaddr() {
		return lextraaddr;
	}
	public void setLextraaddr(String lextraaddr) {
		this.lextraaddr = lextraaddr;
	}
	private String lgrade;
	
	public int getLidx() {
		return lidx;
	}
	public String getLgrade() {
		return lgrade;
	}
	public void setLgrade(String lgrade) {
		this.lgrade = lgrade;
	}
	public void setLidx(int lidx) {
		this.lidx = lidx;
	}
	public String getLid() {
		return lid;
	}
	public void setLid(String lid) {
		this.lid = lid;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getLpwd() {
		return lpwd;
	}
	public void setLpwd(String lpwd) {
		this.lpwd = lpwd;
	}
	public String getLjumin() {
		return ljumin;
	}
	public void setLjumin(String ljumin) {
		this.ljumin = ljumin;
	}
	
	public String getLemail() {
		return lemail;
	}
	public void setLemail(String lemail) {
		this.lemail = lemail;
	}
	public String getLtel() {
		return ltel;
	}
	public void setLtel(String ltel) {
		this.ltel = ltel;
	}
	public String getLcomname() {
		return lcomname;
	}
	public void setLcomname(String lcomname) {
		this.lcomname = lcomname;
	}
	public String getLnumber() {
		return lnumber;
	}
	public void setLnumber(String lnumber) {
		this.lnumber = lnumber;
	}
	public String getLjoindate() {
		return ljoindate;
	}
	public void setLjoindate(String ljoindate) {
		this.ljoindate = ljoindate;
	}
	public String getLoutdate() {
		return loutdate;
	}
	public void setLoutdate(String loutdate) {
		this.loutdate = loutdate;
	}
	public String getLoutyn() {
		return loutyn;
	}
	public void setLoutyn(String loutyn) {
		this.loutyn = loutyn;
	}
	
	public String getLdelyn() {
		return ldelyn;
	}
	public void setLdelyn(String ldelyn) {
		this.ldelyn = ldelyn;
	}
	
	
	
	
	
	
}
