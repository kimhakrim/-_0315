package service;

public class NoticeVo {

	private int nidx;
	private String nsubject;
	private String ncontent;
	private String nwirter;
	private String nwirteday;
	private int nhit;
	private boolean nimage;
	private String nfile;
	private String ndelyn;
	
	
	
	public int getNidx() {
		return nidx;
	}
	public void setNidx(int nidx) {
		this.nidx = nidx;
	}
	public String getNsubject() {
		return nsubject;
	}
	public void setNsubject(String nsubject) {
		this.nsubject = nsubject;
	}
	public String getNcontent() {
		return ncontent;
	}
	public void setNcontent(String ncontent) {
		this.ncontent = ncontent;
	}
	public String getNwirter() {
		return nwirter;
	}
	public void setNwirter(String nwirter) {
		this.nwirter = nwirter;
	}
	public String getNwirteday() {
		return nwirteday;
	}
	public void setNwirteday(String nwirteday) {
		this.nwirteday = nwirteday;
	}
	public int getNhit() {
		return nhit;
	}
	public void setNhit(int nhit) {
		this.nhit = nhit;
	}
	public boolean isNimage() {
		return nimage;
	}
	public void setNimage(boolean nimage) {
		this.nimage = nimage;
	}
	public String getNfile() {
		return nfile;
	}
	public void setNfile(String nfile) {
		this.nfile = nfile;
	}
	public String getNdelyn() {
		return ndelyn;
	}
	public void setNdelyn(String ndelyn) {
		this.ndelyn = ndelyn;
	}
	
}
