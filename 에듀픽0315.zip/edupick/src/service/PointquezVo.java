package service;

public class PointquezVo {

	private int pqidx;
	private String pqcontent;
	private String pqselect;
	private String pqright;
	private String pqsolving;
	private String pqdelyn;
	
	public int getPqidx() {
		return pqidx;
	}
	public void setPqidx(int pqidx) {
		this.pqidx = pqidx;
	}
	public String getPqcontent() {
		return pqcontent;
	}
	public void setPqcontent(String pqcontent) {
		this.pqcontent = pqcontent;
	}
	public String getPqselect() {
		return pqselect;
	}
	public void setPqselect(String pqselect) {
		this.pqselect = pqselect;
	}
	public String getPqright() {
		return pqright;
	}
	public void setPqright(String pqright) {
		this.pqright = pqright;
	}
	public String getPqsolving() {
		return pqsolving;
	}
	public void setPqsolving(String pqsolving) {
		this.pqsolving = pqsolving;
	}
	public String getPqdelyn() {
		return pqdelyn;
	}
	public void setPqdelyn(String pqdelyn) {
		this.pqdelyn = pqdelyn;
	}
	
	
	
}
