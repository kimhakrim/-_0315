package service;

public class CouresVo {

	private int cidx;
	private String cname;
	private String cprice;
	private String couresperiod;
	private String courestime;
	private String recruitpeople;
	
	public int getCidx() {
		return cidx;
	}
	public void setCidx(int cidx) {
		this.cidx = cidx;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCprice() {
		return cprice;
	}
	public void setCprice(String cprice) {
		this.cprice = cprice;
	}
	public String getCouresperiod() {
		return couresperiod;
	}
	public void setCouresperiod(String couresperiod) {
		this.couresperiod = couresperiod;
	}
	public String getCourestime() {
		return courestime;
	}
	public void setCourestime(String courestime) {
		this.courestime = courestime;
	}
	public String getRecruitpeople() {
		return recruitpeople;
	}
	public void setRecruitpeople(String recruitpeople) {
		this.recruitpeople = recruitpeople;
	}
	public String getCbook() {
		return cbook;
	}
	public void setCbook(String cbook) {
		this.cbook = cbook;
	}
	public boolean isCimage() {
		return cimage;
	}
	public void setCimage(boolean cimage) {
		this.cimage = cimage;
	}
	public String getCaim() {
		return caim;
	}
	public void setCaim(String caim) {
		this.caim = caim;
	}
	public String getCregisterdate() {
		return cregisterdate;
	}
	public void setCregisterdate(String cregisterdate) {
		this.cregisterdate = cregisterdate;
	}
	public String getCdelyn() {
		return cdelyn;
	}
	public void setCdelyn(String cdelyn) {
		this.cdelyn = cdelyn;
	}
	private String cbook;
	private boolean cimage;
	private String caim;
	private String cregisterdate;
	private String cdelyn;
}
