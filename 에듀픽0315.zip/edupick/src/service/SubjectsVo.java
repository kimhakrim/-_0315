package service;

public class SubjectsVo {

	private int sidx;
	private String sbiggroup;
	private String smiddlegroup;
	private String ssmallgroup;
	
	public int getSidx() {
		return sidx;
	}
	public void setSidx(int sidx) {
		this.sidx = sidx;
	}
	public String getSbiggroup() {
		return sbiggroup;
	}
	public void setSbiggroup(String sbiggroup) {
		this.sbiggroup = sbiggroup;
	}
	public String getSmiddlegroup() {
		return smiddlegroup;
	}
	public void setSmiddlegroup(String smiddlegroup) {
		this.smiddlegroup = smiddlegroup;
	}
	public String getSsmallgroup() {
		return ssmallgroup;
	}
	public void setSsmallgroup(String ssmallgroup) {
		this.ssmallgroup = ssmallgroup;
	}
	
	
}
