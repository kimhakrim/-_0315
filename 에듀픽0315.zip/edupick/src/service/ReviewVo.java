package service;

public class ReviewVo {
	
	private int ridx;
	private String rcontent;
	private String rwriter;
	private String rwriteday;
	private String rdelyn;
	
	public int getRidx() {
		return ridx;
	}
	public void setRidx(int ridx) {
		this.ridx = ridx;
	}
	public String getRcontent() {
		return rcontent;
	}
	public void setRcontent(String rcontent) {
		this.rcontent = rcontent;
	}
	public String getRwriter() {
		return rwriter;
	}
	public void setRwriter(String rwriter) {
		this.rwriter = rwriter;
	}
	public String getRwriteday() {
		return rwriteday;
	}
	public void setRwriteday(String rwriteday) {
		this.rwriteday = rwriteday;
	}
	public String getRdelyn() {
		return rdelyn;
	}
	public void setRdelyn(String rdelyn) {
		this.rdelyn = rdelyn;
	}

}
