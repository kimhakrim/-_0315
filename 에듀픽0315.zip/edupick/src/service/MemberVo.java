package service;

public class MemberVo {

	private int midx;
	private String mid;
	private String mname;
	private String mpwd;
	private String mjumin;
	private String mpostcode;
	private String mroadaddr;
	private String mjibunaddr;
	private String mdetailaddr;
	private String mextraaddr;
	private String memail;
	private String mtel;
	private String mjoindate;
	private String moutdate;
	private String mdelyn;
	private String mgrade;
	
	
	public String getMpostcode() {
		return mpostcode;
	}
	public void setMpostcode(String mpostcode) {
		this.mpostcode = mpostcode;
	}
	public String getMroadaddr() {
		return mroadaddr;
	}
	public void setMroadaddr(String mroadaddr) {
		this.mroadaddr = mroadaddr;
	}
	public String getMjibunaddr() {
		return mjibunaddr;
	}
	public void setMjibunaddr(String mjibunaddr) {
		this.mjibunaddr = mjibunaddr;
	}
	public String getMdetailaddr() {
		return mdetailaddr;
	}
	public void setMdetailaddr(String mdetailaddr) {
		this.mdetailaddr = mdetailaddr;
	}
	public String getMextraaddr() {
		return mextraaddr;
	}
	public void setMextraaddr(String mextraaddr) {
		this.mextraaddr = mextraaddr;
	}
	public void setMjoindate(String mjoindate) {
		this.mjoindate = mjoindate;
	}
	
	public int getMidx() {
		return midx;
	}
	public void setMidx(int midx) {
		this.midx = midx;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getMpwd() {
		return mpwd;
	}
	public void setMpwd(String mpwd) {
		this.mpwd = mpwd;
	}
	public String getMjumin() {
		return mjumin;
	}
	public void setMjumin(String mjumin) {
		this.mjumin = mjumin;
	}
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	public String getMtel() {
		return mtel;
	}
	public void setMtel(String mtel) {
		this.mtel = mtel;
	}
	public String getMjoindate() {
		return mjoindate;
	}
	public void setMdate(String mjoindate) {
		this.mjoindate = mjoindate;
	}
	public String getMoutdate() {
		return moutdate;
	}
	public void setMoutdate(String moutdate) {
		this.moutdate = moutdate;
	}
	public String getMdelyn() {
		return mdelyn;
	}
	public void setMdelyn(String mdelyn) {
		this.mdelyn = mdelyn;
	}
	public String getMgrade() {
		return mgrade;
	}
	public void setMgrade(String mgrade) {
		this.mgrade = mgrade;
	}
	

}
