package service;

public class PaymentVo {

	private int pdidx;
	private String pddate;
	private String pdprice;
	private String pdmethod;
	private String pddelyn;
	
	public int getPdidx() {
		return pdidx;
	}
	public void setPdidx(int pdidx) {
		this.pdidx = pdidx;
	}
	public String getPddate() {
		return pddate;
	}
	public void setPddate(String pddate) {
		this.pddate = pddate;
	}
	public String getPdprice() {
		return pdprice;
	}
	public void setPdprice(String pdprice) {
		this.pdprice = pdprice;
	}
	public String getPdmethod() {
		return pdmethod;
	}
	public void setPdmethod(String pdmethod) {
		this.pdmethod = pdmethod;
	}
	public String getPddelyn() {
		return pddelyn;
	}
	public void setPddelyn(String pddelyn) {
		this.pddelyn = pddelyn;
	}

}
