package service;

public class CustomerVo {

	private int cuidx;
	private String cusubject;
	private String cucontent;
	private String cuwirter;
	private String cuwirteday;
	private String cupwd;
	private String cucategory;
	private String cufile;
	private String cuing;
	private String cudelyn;

	
	public int getCuidx() {
		return cuidx;
	}
	public void setCuidx(int cuidx) {
		this.cuidx = cuidx;
	}
	public String getCusubject() {
		return cusubject;
	}
	public void setCusubject(String cusubject) {
		this.cusubject = cusubject;
	}
	public String getCucontent() {
		return cucontent;
	}
	public void setCucontent(String cucontent) {
		this.cucontent = cucontent;
	}
	public String getCuwirter() {
		return cuwirter;
	}
	public void setCuwirter(String cuwirter) {
		this.cuwirter = cuwirter;
	}
	public String getCuwirteday() {
		return cuwirteday;
	}
	public void setCuwirteday(String cuwirteday) {
		this.cuwirteday = cuwirteday;
	}
	public String getCupwd() {
		return cupwd;
	}
	public void setCupwd(String cupwd) {
		this.cupwd = cupwd;
	}
	public String getCucategory() {
		return cucategory;
	}
	public void setCucategory(String cucategory) {
		this.cucategory = cucategory;
	}
	public String getCufile() {
		return cufile;
	}
	public void setCufile(String cufile) {
		this.cufile = cufile;
	}
	public String getCuing() {
		return cuing;
	}
	public void setCuing(String cuing) {
		this.cuing = cuing;
	}
	public String getCudelyn() {
		return cudelyn;
	}
	public void setCudelyn(String cudelyn) {
		this.cudelyn = cudelyn;
	}
	
	
}
