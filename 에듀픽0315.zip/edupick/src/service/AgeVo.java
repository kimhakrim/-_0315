package service;

public class AgeVo {

	private int aidx;
	private String agroup;
	
	public int getAidx() {
		return aidx;
	}
	public void setAidx(int aidx) {
		this.aidx = aidx;
	}
	public String getAgroup() {
		return agroup;
	}
	public void setAgroup(String agroup) {
		this.agroup = agroup;
	}
	
	
}
