package service;

public class PointVo {

	private int poidx;
	private String pogetcontent;
	private String pogetpoint;
	private String pousecontent;
	private String pousepoint;
	private String podate;
	private String podelyn;
	
	public int getPoidx() {
		return poidx;
	}
	public void setPoidx(int poidx) {
		this.poidx = poidx;
	}
	public String getPogetcontent() {
		return pogetcontent;
	}
	public void setPogetcontent(String pogetcontent) {
		this.pogetcontent = pogetcontent;
	}
	public String getPogetpoint() {
		return pogetpoint;
	}
	public void setPogetpoint(String pogetpoint) {
		this.pogetpoint = pogetpoint;
	}
	public String getPousecontent() {
		return pousecontent;
	}
	public void setPousecontent(String pousecontent) {
		this.pousecontent = pousecontent;
	}
	public String getPousepoint() {
		return pousepoint;
	}
	public void setPousepoint(String pousepoint) {
		this.pousepoint = pousepoint;
	}
	public String getPodate() {
		return podate;
	}
	public void setPodate(String podate) {
		this.podate = podate;
	}
	public String getPodelyn() {
		return podelyn;
	}
	public void setPodelyn(String podelyn) {
		this.podelyn = podelyn;
	}
	
	
}
