package service;

public class AdviceVo {

	private int adidx;
	private String adicontent;
	private String admcontent;
	private String addate;
	private String starttime;
	private String endtime;
	private String addelyn;

	public int getAdidx() {
		return adidx;
	}
	public void setAdidx(int adidx) {
		this.adidx = adidx;
	}
	public String getAdicontent() {
		return adicontent;
	}
	public void setAdicontent(String adicontent) {
		this.adicontent = adicontent;
	}
	public String getAdmcontent() {
		return admcontent;
	}
	public void setAdmcontent(String admcontent) {
		this.admcontent = admcontent;
	}
	public String getAddate() {
		return addate;
	}
	public void setAddate(String addate) {
		this.addate = addate;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getAddelyn() {
		return addelyn;
	}
	public void setAddelyn(String addelyn) {
		this.addelyn = addelyn;
	}
	
	
}
