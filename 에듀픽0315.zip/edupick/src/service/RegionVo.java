package service;

public class RegionVo {

	private int reidx;
	private String rebiggroup;
	private String remiddlegroup;
	private String resmallgroup;
	
	public int getReidx() {
		return reidx;
	}
	public void setReidx(int reidx) {
		this.reidx = reidx;
	}
	public String getRebiggroup() {
		return rebiggroup;
	}
	public void setRebiggroup(String rebiggroup) {
		this.rebiggroup = rebiggroup;
	}
	public String getRemiddlegroup() {
		return remiddlegroup;
	}
	public void setRemiddlegroup(String remiddlegroup) {
		this.remiddlegroup = remiddlegroup;
	}
	public String getResmallgroup() {
		return resmallgroup;
	}
	public void setResmallgroup(String resmallgroup) {
		this.resmallgroup = resmallgroup;
	}
	
	
	
}
