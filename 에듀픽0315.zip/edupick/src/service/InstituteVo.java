package service;

public class InstituteVo {

	private int iidx;
	private String iname;
	private String iaddr;
	private String itel;
	private String imin;
	private String imax;
	private String isubjects;
	private String ineeds;
	private String iintroduce;
	private boolean iimage;
	private int icommend;
	private int idecaommend;
	private String idelyn;
	
	
	
	
	public int getIidx() {
		return iidx;
	}
	public void setIidx(int iidx) {
		this.iidx = iidx;
	}
	public String getIname() {
		return iname;
	}
	public void setIname(String iname) {
		this.iname = iname;
	}
	public String getIaddr() {
		return iaddr;
	}
	public void setIaddr(String iaddr) {
		this.iaddr = iaddr;
	}
	public String getItel() {
		return itel;
	}
	public void setItel(String itel) {
		this.itel = itel;
	}
	public String getImin() {
		return imin;
	}
	public void setImin(String imin) {
		this.imin = imin;
	}
	public String getImax() {
		return imax;
	}
	public void setImax(String imax) {
		this.imax = imax;
	}
	public String getIsubjects() {
		return isubjects;
	}
	public void setIsubjects(String isubjects) {
		this.isubjects = isubjects;
	}
	public String getIneeds() {
		return ineeds;
	}
	public void setIneeds(String ineeds) {
		this.ineeds = ineeds;
	}
	public String getIintroduce() {
		return iintroduce;
	}
	public void setIintroduce(String iintroduce) {
		this.iintroduce = iintroduce;
	}
	public boolean isIimage() {
		return iimage;
	}
	public void setIimage(boolean iimage) {
		this.iimage = iimage;
	}
	public int getIcommend() {
		return icommend;
	}
	public void setIcommend(int icommend) {
		this.icommend = icommend;
	}
	public int getIdecaommend() {
		return idecaommend;
	}
	public void setIdecaommend(int idecaommend) {
		this.idecaommend = idecaommend;
	}
	public String getIdelyn() {
		return idelyn;
	}
	public void setIdelyn(String idelyn) {
		this.idelyn = idelyn;
	}
	
}
