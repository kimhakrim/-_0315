package service;

public class CommunityVo {

	private int coidx;
	private String cosubject;
	private String cocontent;
	private String cocategory;
	private String cowriteday;
	private int cohit;
	private boolean coimage;
	private String cofile;
	private String codelyn;
	
	public int getCoidx() {
		return coidx;
	}
	public void setCoidx(int coidx) {
		this.coidx = coidx;
	}
	public String getCosubject() {
		return cosubject;
	}
	public void setCosubject(String cosubject) {
		this.cosubject = cosubject;
	}
	public String getCocontent() {
		return cocontent;
	}
	public void setCocontent(String cocontent) {
		this.cocontent = cocontent;
	}
	public String getCocategory() {
		return cocategory;
	}
	public void setCocategory(String cocategory) {
		this.cocategory = cocategory;
	}
	public String getCowriteday() {
		return cowriteday;
	}
	public void setCowriteday(String cowriteday) {
		this.cowriteday = cowriteday;
	}
	public int getCohit() {
		return cohit;
	}
	public void setCohit(int cohit) {
		this.cohit = cohit;
	}
	public boolean isCoimage() {
		return coimage;
	}
	public void setCoimage(boolean coimage) {
		this.coimage = coimage;
	}
	public String getCofile() {
		return cofile;
	}
	public void setCofile(String cofile) {
		this.cofile = cofile;
	}
	public String getCodelyn() {
		return codelyn;
	}
	public void setCodelyn(String codelyn) {
		this.codelyn = codelyn;
	}
	
	
	
}
