package service;

public class VisitVo {
	
	private int vidx;
	private String vdate;
	private String vtime;
	private String vdelyn;
	
	public int getVidx() {
		return vidx;
	}
	public void setVidx(int vidx) {
		this.vidx = vidx;
	}
	public String getVdate() {
		return vdate;
	}
	public void setVdate(String vdate) {
		this.vdate = vdate;
	}
	public String getVtime() {
		return vtime;
	}
	public void setVtime(String vtime) {
		this.vtime = vtime;
	}
	public String getVdelyn() {
		return vdelyn;
	}
	public void setVdelyn(String vdelyn) {
		this.vdelyn = vdelyn;
	}
	
	
	
}
