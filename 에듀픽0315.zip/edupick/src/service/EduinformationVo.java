package service;

public class EduinformationVo {
	
	private int eidx;
	private String esubject;
	private String econtent;
	private String ewirter;
	private String ewirteday;
	private int ehit;
	private boolean eimage;
	private String efile;
	private String edelyn;
	
	public int getEidx() {
		return eidx;
	}
	public void setEidx(int eidx) {
		this.eidx = eidx;
	}
	public String getEsubject() {
		return esubject;
	}
	public void setEsubject(String esubject) {
		this.esubject = esubject;
	}
	public String getEcontent() {
		return econtent;
	}
	public void setEcontent(String econtent) {
		this.econtent = econtent;
	}
	public String getEwirter() {
		return ewirter;
	}
	public void setEwirter(String ewirter) {
		this.ewirter = ewirter;
	}
	public String getEwirteday() {
		return ewirteday;
	}
	public void setEwirteday(String ewirteday) {
		this.ewirteday = ewirteday;
	}
	public int getEhit() {
		return ehit;
	}
	public void setEhit(int ehit) {
		this.ehit = ehit;
	}
	public boolean isEimage() {
		return eimage;
	}
	public void setEimage(boolean eimage) {
		this.eimage = eimage;
	}
	public String getEfile() {
		return efile;
	}
	public void setEfile(String efile) {
		this.efile = efile;
	}
	public String getEdelyn() {
		return edelyn;
	}
	public void setEdelyn(String edelyn) {
		this.edelyn = edelyn;
	}
}
