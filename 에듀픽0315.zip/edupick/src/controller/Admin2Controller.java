package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
	@WebServlet("/Admin2")
	public class Admin2Controller extends HttpServlet{
		private static final long serialVersionUID = 1L;
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			request.setCharacterEncoding("UTF-8");
			//������
			String uri = request.getRequestURI();
			//������Ʈ �̸��� ����
			int len = request.getContextPath().length();
			//������Ʈ �̸��� �� ������
			String str = uri.substring(len);
		
			
			if (str.equals("/Admin2/adminInstituteAdd.do")) {
			
		    RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminInstituteAdd.jsp");
			rd.forward(request, response);	
					
			//������ ��������
		}else if(str.equals("/Admin2/adminInstituteDetail.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminInstituteDetail.jsp");
			rd.forward(request, response);	
			
		
			
		}else if(str.equals("/Admin2/adminInstituteModify.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminInstituteModify.jsp");
			rd.forward(request, response);	
			
		
			
		}else if(str.equals("/Admin2/adminCoures.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminCoures.jsp");
			rd.forward(request, response);	
		
	
		}else if(str.equals("/Admin2/adminCouresDetail.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminCouresDetail.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminCouresModify.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminCouresModify.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminCommunityDetail.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminCommunityDetail.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminOrderManage.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminOrderManage.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminPayDetail.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminPayDetail.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminProductManage.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminProductManage.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminReviewDetail.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminReviewDetail.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminStudentDetail.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminStudentDetail.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminStudentModify.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminStudentModify.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminVisitDetail.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminVisitDetail.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/adminPageManage.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/adminPageManage.jsp");
			rd.forward(request, response);	
		
		
		}else if(str.equals("/Admin2/admin.do")) {
			
			RequestDispatcher rd = request.getRequestDispatcher("/jsp/admin.jsp");
			rd.forward(request, response);	
		
		
		}
			
			
	
	
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doGet(request, response);
	}
}


