﻿function visitbtn() {
	location.href="/edupick/Common/main.do";
}