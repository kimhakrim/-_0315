﻿function yescan() {
	top.opener.location="cart.do";
	window.close();
}

function shop(){
	window.close();
}