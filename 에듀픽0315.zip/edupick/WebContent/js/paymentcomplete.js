﻿function page(){
opener.parent.location="learnerinformation.do";
window.close();
}